document.querySelector("#AC").addEventListener("mousedown",()=>{

    document.querySelector("#AC").classList.add('topRowKeysPressed')
})
document.querySelector("#AC").addEventListener("mouseup",()=>{

    document.querySelector("#AC").classList.remove('topRowKeysPressed')
})

// define our own selector
const $$ = (selector)=>{
    return document.querySelector(selector);
}

const getCurrentOutput = ()=> $$('#output').innerText;
const setCurrentOutput = (val)=> $$('#output').innerText=val;

let inputKey ="";
let previousKey ="0";
const operators ="/*-+";
const mainCalculatorBody = $$("#mainCalculatorBody");

mainCalculatorBody.addEventListener('click',(e)=>{

    if(e.target && e.target.nodeName){
        inputKey = e.target.innerText

        // if the input key is numeric
        if(parseInt(inputKey) in [0,1,3,4,5,6,7,8,9,10])
        {
            if(getCurrentOutput() === '0'){
                setCurrentOutput(inputKey)
                previousKey = inputKey;
            }
            else{
                setCurrentOutput((getCurrentOutput()).toString() + inputKey.toString())
                previousKey = inputKey;
            }
        }
        // if the input key is an operation
        // in won't work here:
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/in

        if(operators.includes(inputKey))
        {
            if(!operators.includes(previousKey)){
                setCurrentOutput((getCurrentOutput()).toString() + inputKey.toString())
                previousKey = inputKey;
            }
            else{
                setCurrentOutput((getCurrentOutput()).toString().slice(0,-1) + inputKey.toString())
                previousKey = inputKey;
            }
        }
        if(inputKey=== '='){
            try{
                setCurrentOutput(eval(getCurrentOutput()));
            }
            catch (ex){
                setCurrentOutput("Error!")
            }

        }
        if(inputKey=== 'AC'){
            setCurrentOutput('0')
        }
        if(inputKey=== '+/-'){
            setCurrentOutput(-1*eval(getCurrentOutput()));
        }
        if(inputKey=== '%'){
            setCurrentOutput(eval(getCurrentOutput())/100);
        }
    }
})
