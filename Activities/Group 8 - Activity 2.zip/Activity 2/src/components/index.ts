import Home from "./Home";
import Navigation from "./Navigation";
import Products from "./Products";
import About from "./About";

export { Home, Navigation, Products, About };
