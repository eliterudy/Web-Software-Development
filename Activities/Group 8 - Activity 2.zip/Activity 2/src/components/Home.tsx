import React, { useState, useEffect } from "react";

const Home = () => {
  return (
    <>
      <p>Home Page</p>
    </>
  );
};

export default Home;
