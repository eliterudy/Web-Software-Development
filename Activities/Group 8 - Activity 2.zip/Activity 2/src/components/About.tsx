import React, { useState, useEffect } from "react";

const About = () => {
  return (
    <>
      <p>About Page</p>
    </>
  );
};

export default About;
